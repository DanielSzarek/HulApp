import React from 'react';
import '../Styles/AnonymousPage.css';
import logo from '../Images/logo_hulapp.png';




class AnonymousPage extends React.Component {

    render(){
        return(
            <div>
                <div className="offset-md-0 col-12 col-md-6">
                    <img src={logo} alt={"logo"} className="photoAnonymous" />
                    <div>
                        <h2>Kim jesteśmy?</h2>
                        <h3>Jesteśmy grupą młdych ludzi pozytywnie zakręconych. Co nas kręci? </h3>
                        <h3>Kręci nas miasto! Kręcą nas ludzie i wpsólnie spędzony czas naświeżym powietrzu.</h3>
                    </div>
                </div>
                
                
                <div className="offset-md-6 col-12 col-md-12 " style={{backgroundColor:'red', height:'100%', backgroundSize:'cover'}}>
                    <div className="redbcg">
                        <div className="col-6">
                            <h1>hey2</h1>
                        </div>
                    </div>
                </div>
            </div>

        )
    }
}
export default AnonymousPage;